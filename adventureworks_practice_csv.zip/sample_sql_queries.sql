-- Sample practice SQL queries for AdventureWorks-style CSV tables after loading them to SQL/Fabric

-- 1. Internet sales by year and product category
SELECT
    d.CalendarYear,
    pc.EnglishProductCategoryName,
    SUM(f.SalesAmount) AS SalesAmount,
    SUM(f.TotalProductCost) AS TotalProductCost,
    SUM(f.SalesAmount - f.TotalProductCost) AS GrossMargin
FROM FactInternetSales f
JOIN DimDate d ON f.OrderDateKey = d.DateKey
JOIN DimProduct p ON f.ProductKey = p.ProductKey
JOIN DimProductSubcategory ps ON p.ProductSubcategoryKey = ps.ProductSubcategoryKey
JOIN DimProductCategory pc ON ps.ProductCategoryKey = pc.ProductCategoryKey
GROUP BY d.CalendarYear, pc.EnglishProductCategoryName
ORDER BY d.CalendarYear, SalesAmount DESC;

-- 2. Top 10 products by combined internet + reseller sales
WITH CombinedSales AS (
    SELECT ProductKey, SalesAmount, TotalProductCost FROM FactInternetSales
    UNION ALL
    SELECT ProductKey, SalesAmount, TotalProductCost FROM FactResellerSales
)
SELECT TOP 10
    p.EnglishProductName,
    SUM(cs.SalesAmount) AS SalesAmount,
    SUM(cs.TotalProductCost) AS TotalProductCost,
    SUM(cs.SalesAmount - cs.TotalProductCost) AS GrossMargin
FROM CombinedSales cs
JOIN DimProduct p ON cs.ProductKey = p.ProductKey
GROUP BY p.EnglishProductName
ORDER BY SalesAmount DESC;

-- 3. Reseller sales by sales rep
SELECT
    e.FullName AS SalesRep,
    st.SalesTerritoryRegion,
    SUM(f.SalesAmount) AS ResellerSales
FROM FactResellerSales f
JOIN DimEmployee e ON f.EmployeeKey = e.EmployeeKey
JOIN DimSalesTerritory st ON f.SalesTerritoryKey = st.SalesTerritoryKey
GROUP BY e.FullName, st.SalesTerritoryRegion
ORDER BY ResellerSales DESC;
