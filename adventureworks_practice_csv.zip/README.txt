AdventureWorks-style CSV Practice Pack

This is a generated practice dataset modeled after common AdventureWorksDW tables. It is not the official Microsoft AdventureWorks database export.

Suggested Power BI relationships:
- FactInternetSales[ProductKey] -> DimProduct[ProductKey]
- FactInternetSales[CustomerKey] -> DimCustomer[CustomerKey]
- FactInternetSales[OrderDateKey] -> DimDate[DateKey]
- FactInternetSales[SalesTerritoryKey] -> DimSalesTerritory[SalesTerritoryKey]
- FactInternetSales[PromotionKey] -> DimPromotion[PromotionKey]
- FactInternetSales[CurrencyKey] -> DimCurrency[CurrencyKey]
- FactResellerSales[ProductKey] -> DimProduct[ProductKey]
- FactResellerSales[ResellerKey] -> DimReseller[ResellerKey]
- FactResellerSales[EmployeeKey] -> DimEmployee[EmployeeKey]
- FactResellerSales[OrderDateKey] -> DimDate[DateKey]
- DimProduct[ProductSubcategoryKey] -> DimProductSubcategory[ProductSubcategoryKey]
- DimProductSubcategory[ProductCategoryKey] -> DimProductCategory[ProductCategoryKey]
- DimCustomer[GeographyKey] -> DimGeography[GeographyKey]
- DimReseller[GeographyKey] -> DimGeography[GeographyKey]

Suggested DAX measures:
Sales Amount = SUM(FactInternetSales[SalesAmount]) + SUM(FactResellerSales[SalesAmount])
Total Cost = SUM(FactInternetSales[TotalProductCost]) + SUM(FactResellerSales[TotalProductCost])
Gross Margin = [Sales Amount] - [Total Cost]
Margin % = DIVIDE([Gross Margin], [Sales Amount])
